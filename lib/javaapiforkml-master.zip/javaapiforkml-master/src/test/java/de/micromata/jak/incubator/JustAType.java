/////////////////////////////////////////////////////////////////////////////
//
// $RCSfile: $
//
// Project   JavaAPIforKML
//
// Author    Flori (f.bachmann@micromata.de)
// Created   Aug 17, 2009
// Copyright Micromata Aug 17, 2009
//
// $Id: $
// $Revision: $
// $Date: $
//
/////////////////////////////////////////////////////////////////////////////
package de.micromata.jak.incubator;

public class JustAType {
	private boolean foo;

	public void setFoo(boolean foo) {
	  this.foo = foo;
  }

	public boolean isFoo() {
	  return foo;
  }
}
