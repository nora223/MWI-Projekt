
package de.micromata.opengis.kml.v_2_2_0.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
public @interface Obvious {


}
