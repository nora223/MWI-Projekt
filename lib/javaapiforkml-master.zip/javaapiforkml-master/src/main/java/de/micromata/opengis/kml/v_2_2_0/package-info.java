@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.opengis.net/kml/2.2", xmlns = {
    @javax.xml.bind.annotation.XmlNs( prefix = "kml", namespaceURI = "http://www.opengis.net/kml/2.2" )
},
elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.micromata.opengis.kml.v_2_2_0;
